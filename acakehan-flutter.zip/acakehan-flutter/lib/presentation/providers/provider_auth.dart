// ============================================================
//  ACAKEHAN — Aplikasi Catatan Keuangan Harian
//  File   : lib/presentation/providers/provider_auth.dart
//  Fungsi : State management autentikasi menggunakan Riverpod
//           AsyncNotifier — mengelola status login/logout
// ============================================================

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/models/model_data.dart';
import '../../data/repositories/repositori_auth.dart';

// ── State autentikasi ──────────────────────────────────────────
class StateAuth {
  final ModelPengguna? pengguna;
  final bool sedangMemuat;
  final String? pesanError;
  final bool sudahLogin;

  const StateAuth({
    this.pengguna,
    this.sedangMemuat = false,
    this.pesanError,
    this.sudahLogin = false,
  });

  StateAuth salin({
    ModelPengguna? pengguna,
    bool? sedangMemuat,
    String? pesanError,
    bool? sudahLogin,
    bool hapusError = false,
  }) {
    return StateAuth(
      pengguna:      pengguna   ?? this.pengguna,
      sedangMemuat:  sedangMemuat ?? this.sedangMemuat,
      pesanError:    hapusError ? null : (pesanError ?? this.pesanError),
      sudahLogin:    sudahLogin ?? this.sudahLogin,
    );
  }
}

// ── Notifier ───────────────────────────────────────────────────
class NotifierAuth extends StateNotifier<StateAuth> {
  final RepositoriAuth _repositori;

  NotifierAuth(this._repositori) : super(const StateAuth()) {
    _periksaStatusLogin();
  }

  /// Periksa apakah sudah ada sesi login tersimpan saat app dibuka.
  Future<void> _periksaStatusLogin() async {
    final sudah    = await _repositori.sudahLogin();
    final pengguna = await _repositori.ambilProfilLokal();
    state = state.salin(sudahLogin: sudah, pengguna: pengguna);
  }

  /// Proses login dengan email dan kata sandi.
  Future<bool> masuk({required String email, required String kataSandi}) async {
    state = state.salin(sedangMemuat: true, hapusError: true);
    try {
      final hasil = await _repositori.masuk(
        email:     email,
        kataSandi: kataSandi,
      );
      state = state.salin(
        pengguna:     hasil.pengguna,
        sudahLogin:   true,
        sedangMemuat: false,
      );
      return true;
    } catch (galat) {
      state = state.salin(
        sedangMemuat: false,
        pesanError:   galat.toString().replaceFirst('Exception: ', ''),
      );
      return false;
    }
  }

  /// Proses registrasi akun baru.
  Future<bool> daftar({
    required String namaLengkap,
    required String email,
    required String kataSandi,
    required String konfirmasiKataSandi,
  }) async {
    state = state.salin(sedangMemuat: true, hapusError: true);
    try {
      final hasil = await _repositori.daftar(
        namaLengkap:          namaLengkap,
        email:                email,
        kataSandi:            kataSandi,
        konfirmasiKataSandi:  konfirmasiKataSandi,
      );
      state = state.salin(
        pengguna:     hasil.pengguna,
        sudahLogin:   true,
        sedangMemuat: false,
      );
      return true;
    } catch (galat) {
      state = state.salin(
        sedangMemuat: false,
        pesanError:   galat.toString().replaceFirst('Exception: ', ''),
      );
      return false;
    }
  }

  /// Logout — hapus token dan reset state.
  Future<void> keluar() async {
    state = state.salin(sedangMemuat: true);
    await _repositori.keluar();
    state = const StateAuth(sudahLogin: false);
  }

  void hapusError() => state = state.salin(hapusError: true);
}

// ── Provider global ────────────────────────────────────────────
final providerAuthNotifier = StateNotifierProvider<NotifierAuth, StateAuth>((ref) {
  return NotifierAuth(ref.watch(repositoriAuthProvider));
});

// ── Provider turunan ───────────────────────────────────────────
final providerSudahLogin    = Provider<bool>((ref) =>
    ref.watch(providerAuthNotifier).sudahLogin);

final providerPenggunaAktif = Provider<ModelPengguna?>((ref) =>
    ref.watch(providerAuthNotifier).pengguna);
