// ============================================================
//  ACAKEHAN — Aplikasi Catatan Keuangan Harian
//  File   : lib/main.dart
//  Fungsi : Entry point utama — inisialisasi Flutter,
//           Riverpod, intl, dan konfigurasi tema aplikasi.
// ============================================================

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/date_symbol_data_local.dart';

import 'core/router/router_app.dart';
import 'presentation/theme/tema_acakehan.dart';

Future<void> main() async {
  // Pastikan binding Flutter sudah siap sebelum kode async dijalankan
  WidgetsFlutterBinding.ensureInitialized();

  // Inisialisasi data lokal Bahasa Indonesia untuk format tanggal
  await initializeDateFormatting('id_ID', null);

  // Kunci orientasi layar ke mode portrait saja
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  // Konfigurasi tampilan status bar agar transparan
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor:           Colors.transparent,
      statusBarIconBrightness:  Brightness.dark,
      systemNavigationBarColor: Colors.white,
      systemNavigationBarIconBrightness: Brightness.dark,
    ),
  );

  runApp(
    // ProviderScope WAJIB membungkus seluruh app untuk Riverpod
    const ProviderScope(
      child: AplikasiAcakehan(),
    ),
  );
}

class AplikasiAcakehan extends ConsumerWidget {
  const AplikasiAcakehan({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // Ambil instance GoRouter dari provider
    final router = ref.watch(providerRouter);

    return MaterialApp.router(
      // ── Identitas ─────────────────────────────────────────
      title:            'Acakehan',
      debugShowCheckedModeBanner: false,

      // ── Tema ──────────────────────────────────────────────
      theme:      TemaAcakehan.temaTerang,
      themeMode:  ThemeMode.light,

      // ── Router ────────────────────────────────────────────
      routerConfig: router,

      // ── Lokalisasi ────────────────────────────────────────
      locale:                   const Locale('id', 'ID'),
      supportedLocales:         const [Locale('id', 'ID'), Locale('en', 'US')],
    );
  }
}
