// ============================================================
//  ACAKEHAN — Aplikasi Catatan Keuangan Harian
//  File   : lib/core/router/router_app.dart
//  Fungsi : Konfigurasi navigasi GoRouter — menentukan rute,
//           redirect berdasarkan status login, dan transisi halaman.
// ============================================================

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

import '../../presentation/providers/provider_auth.dart';
import '../../presentation/screens/auth/halaman_masuk.dart';
import '../../presentation/screens/dashboard/halaman_dashboard.dart';
import '../constants/konstanta_app.dart';

// ── Provider GoRouter ──────────────────────────────────────────
final providerRouter = Provider<GoRouter>((ref) {
  // Pantau state autentikasi untuk redirect otomatis
  final stateAuth = ref.watch(providerAuthNotifier);

  return GoRouter(
    initialLocation: NamaRoute.sambutan,
    debugLogDiagnostics: true,

    // ── Redirect global berdasarkan status login ───────────
    redirect: (context, state) {
      final sudahLogin    = stateAuth.sudahLogin;
      final sedangMemuat  = stateAuth.sedangMemuat;
      final lokasiSaat    = state.matchedLocation;

      // Jangan redirect saat sedang memeriksa status login
      if (sedangMemuat) return null;

      final diHalamanAuth = lokasiSaat == NamaRoute.masuk ||
                            lokasiSaat == NamaRoute.daftar ||
                            lokasiSaat == NamaRoute.sambutan;

      // Belum login dan bukan di halaman auth → ke halaman login
      if (!sudahLogin && !diHalamanAuth) return NamaRoute.masuk;

      // Sudah login dan masih di halaman auth → ke dashboard
      if (sudahLogin && diHalamanAuth) return NamaRoute.dashboard;

      return null; // Tidak perlu redirect
    },

    // ── Daftar Rute ────────────────────────────────────────
    routes: [
      // ── Sambutan (splash screen singkat) ──────────────────
      GoRoute(
        path: NamaRoute.sambutan,
        builder: (_, __) => const _HalamanSambutan(),
      ),

      // ── Autentikasi ────────────────────────────────────────
      GoRoute(
        path:    NamaRoute.masuk,
        name:    'masuk',
        builder: (_, __) => const HalamanMasuk(),
        pageBuilder: (_, state) => CustomTransitionPage(
          key:       state.pageKey,
          child:     const HalamanMasuk(),
          transitionsBuilder: _transisiSlideKanan,
        ),
      ),

      // ── Dashboard ──────────────────────────────────────────
      GoRoute(
        path:    NamaRoute.dashboard,
        name:    'dashboard',
        builder: (_, __) => const HalamanDashboard(),
        pageBuilder: (_, state) => CustomTransitionPage(
          key:       state.pageKey,
          child:     const HalamanDashboard(),
          transitionsBuilder: _transisiFade,
        ),
      ),
    ],

    // ── Halaman Error ──────────────────────────────────────
    errorBuilder: (context, state) => Scaffold(
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.error_outline_rounded, size: 64, color: Colors.red),
            const SizedBox(height: 16),
            Text(
              'Halaman tidak ditemukan',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 8),
            Text(state.error.toString()),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () => context.go(NamaRoute.masuk),
              child:     const Text('Kembali ke Login'),
            ),
          ],
        ),
      ),
    ),
  );
});

// ── Fungsi Transisi Animasi ────────────────────────────────────
Widget _transisiSlideKanan(
  BuildContext context,
  Animation<double> animasi,
  Animation<double> animasiSekunder,
  Widget child,
) {
  return SlideTransition(
    position: Tween<Offset>(
      begin: const Offset(1, 0),
      end:   Offset.zero,
    ).animate(CurvedAnimation(parent: animasi, curve: Curves.easeOutCubic)),
    child: child,
  );
}

Widget _transisiFade(
  BuildContext context,
  Animation<double> animasi,
  Animation<double> animasiSekunder,
  Widget child,
) {
  return FadeTransition(
    opacity: CurvedAnimation(parent: animasi, curve: Curves.easeIn),
    child:   child,
  );
}

// ── Halaman Sambutan (Splash Screen) ──────────────────────────
class _HalamanSambutan extends ConsumerWidget {
  const _HalamanSambutan();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // Halaman ini hanya tampil sesaat sebelum redirect dilakukan
    // oleh GoRouter berdasarkan status autentikasi
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin:  Alignment.topLeft,
            end:    Alignment.bottomRight,
            colors: [Color(0xFF134E4A), Color(0xFF0F172A)],
          ),
        ),
        child: const Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                '₿',
                style: TextStyle(
                  fontSize:  64,
                  color:     Colors.white,
                ),
              ),
              SizedBox(height: 16),
              Text(
                'Acakehan',
                style: TextStyle(
                  fontFamily:  'Sora',
                  fontSize:    32,
                  fontWeight:  FontWeight.w800,
                  color:       Colors.white,
                  letterSpacing: -0.5,
                ),
              ),
              SizedBox(height: 32),
              CircularProgressIndicator(
                color:       Color(0xFF14B8A6),
                strokeWidth: 2.5,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
