"""
============================================================
  ACAKEHAN — Aplikasi Catatan Keuangan Harian
  File   : app/config/database.py
  Fungsi : Inisialisasi koneksi database SQLAlchemy,
           manajemen sesi, dan dependency injection untuk FastAPI
============================================================
"""

from typing import Generator
from sqlalchemy import create_engine, event, text
from sqlalchemy.orm import sessionmaker, DeclarativeBase, Session
from sqlalchemy.pool import QueuePool

from app.config.pengaturan import ambilPengaturan

# Ambil konfigurasi global
cfg = ambilPengaturan()


# ============================================================
#  Base Class untuk semua Model ORM
# ============================================================
class ModelDasar(DeclarativeBase):
    """
    Kelas dasar yang diwarisi oleh semua model database Acakehan.
    SQLAlchemy menggunakan kelas ini untuk mendeteksi tabel mana saja
    yang perlu dibuat saat db.create_all() dipanggil.
    """
    pass


# ============================================================
#  Engine Database
# ============================================================
engineDatabase = create_engine(
    cfg.uriDatabase,
    poolclass=QueuePool,
    pool_size=cfg.DB_POOL_SIZE,       # Jumlah koneksi aktif di pool
    max_overflow=cfg.DB_MAX_OVERFLOW, # Koneksi tambahan saat pool penuh
    pool_pre_ping=True,               # Cek koneksi sebelum dipakai (cegah "stale connection")
    pool_recycle=3600,                # Daur ulang koneksi setiap 1 jam
    echo=cfg.MODE_DEBUG,              # Tampilkan query SQL di console (mode debug)
)


# ============================================================
#  Session Factory
# ============================================================
# SessionLokal adalah "pabrik" yang menghasilkan sesi database baru.
# autocommit=False → perubahan harus di-commit() secara eksplisit
# autoflush=False  → tidak otomatis flush sebelum query (lebih terkontrol)
SessionLokal = sessionmaker(
    bind=autocommit_False := engineDatabase,
    autocommit=False,
    autoflush=False,
)

# Koreksi: sessionmaker menerima bind langsung
SessionLokal = sessionmaker(
    bind=engineDatabase,
    autocommit=False,
    autoflush=False,
)


# ============================================================
#  Dependency Injection: ambilSesiDB()
# ============================================================
def ambilSesiDB() -> Generator[Session, None, None]:
    """
    FastAPI Dependency — menyediakan sesi database untuk setiap request.

    Pola Generator digunakan agar sesi SELALU ditutup setelah
    request selesai, bahkan jika terjadi exception.

    Cara pakai di endpoint:
        from fastapi import Depends
        from app.config.database import ambilSesiDB

        @router.get("/contoh")
        def endpoint_contoh(db: Session = Depends(ambilSesiDB)):
            hasil = db.query(Model).all()
            return hasil
    """
    sesi = SessionLokal()
    try:
        yield sesi          # Berikan sesi ke endpoint
        sesi.commit()       # Auto-commit jika tidak ada error
    except Exception:
        sesi.rollback()     # Batalkan semua perubahan jika ada error
        raise               # Lempar kembali exception agar FastAPI bisa tangani
    finally:
        sesi.close()        # Selalu tutup sesi, apapun yang terjadi


# ============================================================
#  Fungsi Utilitas Database
# ============================================================
def buatSemuaTabel() -> None:
    """
    Membuat semua tabel di database berdasarkan definisi model.
    Dipanggil satu kali saat aplikasi pertama dijalankan.
    """
    ModelDasar.metadata.create_all(bind=engineDatabase)
    print("[DB] Semua tabel berhasil diinisialisasi.")


def periksaKoneksiDB() -> bool:
    """
    Menguji apakah koneksi ke database berhasil.
    Digunakan di health check endpoint.

    Returns:
        True jika koneksi berhasil, False jika gagal.
    """
    try:
        with engineDatabase.connect() as koneksi:
            koneksi.execute(text("SELECT 1"))
        return True
    except Exception as galat:
        print(f"[DB ERROR] Koneksi database gagal: {str(galat)}")
        return False
